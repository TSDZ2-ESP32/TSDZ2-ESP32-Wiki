
[System.Reflection.Assembly]::LoadWithPartialName("System.IO.Ports.SerialPort")
$COMports = [System.IO.Ports.SerialPort]::getportnames()

if ($COMports.count -gt 1) {
	Write-Host "Multiple ports were found" -ForegroundColor Yellow
	Write-Host "Please select a COM Port" -ForegroundColor Yellow
	for($i = 0; $i -lt $COMports.count; $i++){
		$temp = new-object System.IO.Ports.SerialPort $COMports[$i]
		Write-Host "$($i): $($temp.PortName)"
		$temp.Dispose() 
	}
	[int] $selection = Read-Host -Prompt "Enter the number of the port"
	if ($selection -ge $COMports.count -Or $selection -lt 0) {
		Write-Host 'Number out of range' -ForegroundColor Red
		exit 1;	
	}
} elseif ($COMports -eq $null -Or $COMports.count -eq 0) {
	Write-Host "No COM ports were found" -ForegroundColor Yellow
	exit 1;
} else {
	$selection = 0
}

$temp = new-object System.IO.Ports.SerialPort $COMports[$selection]
$port_name = $temp.PortName
$temp.Dispose() 
	
Write-Host ""
Write-Host "Writing to Port $($port_name)"
write-host "Press any key to continue..."
[void][System.Console]::ReadKey($true)
Write-Host ""

& "./esptool.exe" -p $($port_name) -b 460800 --after hard_reset write_flash --flash_mode dio --flash_size detect --flash_freq 40m 0x1000 FW\bootloader.bin 0xf000 FW\partition-table.bin 0x2d000 FW\ota_data_initial.bin 0x30000 FW\TSDZ2-ESP32-Main.bin

exit 0;

